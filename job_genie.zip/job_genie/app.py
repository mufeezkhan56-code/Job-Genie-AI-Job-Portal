from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_dance.contrib.google import make_google_blueprint, google
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
import os, csv, fitz, docx, spacy, json, joblib
import time



# ✅ Allow OAuth over HTTP (only for development/testing)
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

# ✅ Define the Flask app FIRST
app = Flask(__name__)
app.secret_key = '11223344'

# --- Google OAuth (Flask-Dance) ---

google_bp = make_google_blueprint(
    client_id="942342789678-pknk9i6ug52rikttiqe4na78jl1inq9i.apps.googleusercontent.com",
    client_secret="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",
    scope=[
        "https://www.googleapis.com/auth/userinfo.profile",
        "https://www.googleapis.com/auth/userinfo.email",
        "openid"
    ],
    redirect_to="google_login"  # send back to your route after auth
)
app.register_blueprint(google_bp, url_prefix="/login")







login_manager = LoginManager()
login_manager.init_app(app)

# Optional: where to redirect when login is required
login_manager.login_view = "login"        # change if your login endpoint is different
login_manager.login_message_category = "info"

# Tell Flask-Login how to load a user from the session user_id
@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except Exception:
        return None
# Upload Config
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'docx'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Database Config
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///jobgenie.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# NLP and ML
nlp = spacy.load("en_core_web_sm")
model = joblib.load('model/resume_model.pkl')
vectorizer = joblib.load('model/tfidf.pkl')

# --------- MODELS ---------
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False, unique=True)
    email = db.Column(db.String(120), nullable=False, unique=True)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='jobseeker')
    applications = db.relationship('Application', backref='user', lazy=True)

    def __repr__(self):
        return f"<User {self.username} ({self.email})>"



class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    recruiter_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    applications = db.relationship('Application', backref='job', lazy=True)


    __table_args__ = (db.UniqueConstraint('recruiter_id', 'title', 'description', name='unique_job_post'),)

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    resume_filename = db.Column(db.String(200))  # 👈 Add this line


    __table_args__ = (db.UniqueConstraint('user_id', 'job_id', name='unique_application'),)
class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    message = db.Column(db.String(400), nullable=False)
    read = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, server_default=db.func.current_timestamp())

    def __repr__(self):
        return f"<Notification {self.id} to user {self.user_id}>"



# --------- HELPERS ---------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def extract_text_from_pdf(path):
    text = ""
    with fitz.open(path) as doc:
        for page in doc:
            text += page.get_text()
    return text

def extract_text_from_docx(path):
    doc = docx.Document(path)
    return "\n".join(para.text for para in doc.paragraphs)

def analyze_resume_text(text, filename, user_id=None):
    # user_id: int or None. If None, fallback to session user.
    if user_id is None:
        user_id = session.get('user_id', '')

    doc = nlp(text)
    tokens = [t.text.lower() for t in doc if not t.is_stop and not t.is_punct]
    keywords = ['python', 'flask', 'machine learning', 'nlp', 'sql', 'django']
    score = sum(1 for word in keywords if word in tokens)

    # Keep line breaks and create preview
    resume_text = text.strip()
    preview_text = text[:300].strip() + ("..." if len(text) > 300 else "")

    csv_file = "resume_data.csv"
    header_expected = ['filename', 'excerpt', 'score', 'full_text', 'shortlisted', 'user_id']

    # If CSV does not exist -> create with header and first row
    if not os.path.exists(csv_file):
        with open(csv_file, "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file, quoting=csv.QUOTE_ALL)
            writer.writerow(header_expected)
            writer.writerow([filename, preview_text, score, resume_text, "no", user_id])
        return int(score)

    # If CSV exists, read to check header
    with open(csv_file, "r", newline="", encoding="utf-8") as file:
        rows = list(csv.reader(file))
        if not rows:
            # empty file -> write header + row
            with open(csv_file, "w", newline="", encoding="utf-8") as f2:
                writer = csv.writer(f2, quoting=csv.QUOTE_ALL)
                writer.writerow(header_expected)
                writer.writerow([filename, preview_text, score, resume_text, "no", user_id])
            return int(score)

        first_row = rows[0]
        header_tokens = [h.strip().lower() for h in first_row]
        has_user_id = 'user_id' in header_tokens

    # CASE A: file already uses user_id column -> append row
    if has_user_id:
        with open(csv_file, "a", newline="", encoding="utf-8") as file:
            writer = csv.writer(file, quoting=csv.QUOTE_ALL)
            writer.writerow([filename, preview_text, score, resume_text, "no", user_id])
        return int(score)

    # CASE B: old CSV without user_id -> migrate by rewriting with new header and appending blank user_id for old rows
    temp_file = csv_file + ".tmp"
    with open(csv_file, "r", newline="", encoding="utf-8") as fin, \
         open(temp_file, "w", newline="", encoding="utf-8") as fout:

        reader = csv.reader(fin)
        writer = csv.writer(fout, quoting=csv.QUOTE_ALL)

        # write new header
        writer.writerow(header_expected)

        for i, row in enumerate(reader):
            # skip original header (if it looks like header)
            if i == 0:
                tokens = [c.strip().lower() for c in row]
                if any(tok in ('filename', 'excerpt', 'score', 'full_text', 'shortlisted') for tok in tokens):
                    continue

            # normalize to at least 5 columns (filename, excerpt, score, full_text, shortlisted)
            if len(row) < 5:
                row = row + [''] * (5 - len(row))

            # If row has extra columns due to embedded commas, collapse extras into full_text
            if len(row) > 5:
                # merge columns 3..(len-2) into full_text (index 3)
                start_collapse = 3
                end_collapse = len(row) - 2
                collapsed = ",".join(row[start_collapse:end_collapse + 1])
                row = row[:start_collapse] + [collapsed] + row[-2:]

            # ensure exactly 5 main cols, then add blank user_id for old rows
            row = row[:5] + ['']

            writer.writerow(row)

        # finally append the new upload row with user_id
        writer.writerow([filename, preview_text, score, resume_text, "no", user_id])

    # atomically replace old csv
    os.replace(temp_file, csv_file)
    return int(score)


def predict_resume_strength(text):
    vec = vectorizer.transform([text])
    label = int(model.predict(vec)[0])
    conf = float(model.predict_proba(vec)[0][label])
    return label, round(conf * 100)

def match_jobs_with_resume(resume_text):
    try:
        with open('jobs.json') as f:
            job_data = json.load(f)
    except FileNotFoundError:
        return []

    resume_tokens = {t.text for t in nlp(resume_text.lower()) if not t.is_stop and not t.is_punct}
    matches = []

    for job in job_data:
        job_tokens = {t.text for t in nlp(job['description'].lower()) if not t.is_stop and not t.is_punct}
        common = resume_tokens.intersection(job_tokens)
        score = int((len(common) / len(job_tokens)) * 100) if job_tokens else 0

        # 🧠 Look up Job ID from the database using title and description
        job_db = Job.query.filter_by(title=job['title'], description=job['description']).first()
        job_id = job_db.id if job_db else None

        matches.append({
            'title': job['title'],
            'description': job['description'],
            'score': score,
            'skills_matched': list(common),
            'job_id': job_id
        })

    matches.sort(key=lambda x: x['score'], reverse=True)
    return matches[:3]

# --------- ROUTES ---------

@app.route('/')
def home():
    return render_template('index.html')

# --- Authentication ---
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username, email, password = request.form['username'], request.form['email'], request.form['password']
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash('Username or Email exists!', 'danger')
            return redirect(url_for('register'))

        hashed = generate_password_hash(password)
        db.session.add(User(username=username, email=email, password=hashed, role='jobseeker'))
        db.session.commit()
        flash('Registered! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username, password = request.form['username'], request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            session['user_id'], session['username'], session['role'] = user.id, user.username, user.role
            flash('Logged in!', 'success')
            return redirect(url_for('recruiter_dashboard') if user.role == 'recruiter' else url_for('jobseeker_dashboard'))

        flash('Invalid credentials.', 'danger')
        return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    # Log out from Flask-Login
    logout_user()

    # Remove Google OAuth token if present (prevents account sticking)
    session.pop("google_oauth_token", None)

    # Remove stored resume filename so it doesn't persist between users
    session.pop("resume_filename", None)

    # Optionally clear any other session keys you don't want to keep
    # session.pop("resume_text", None)
    # session.pop("resume_score", None)
    # session.pop("pending_role", None)

    # Finally clear the rest of session data
    session.clear()

    flash("Logged out.", "info")
    return redirect(url_for("home"))

# --- Job Seeker ---
@app.route('/jobseeker/dashboard')
@login_required
def jobseeker_dashboard():
    if session.get('role') != 'jobseeker':
        flash('Access Denied.', 'danger')
        return redirect(url_for('home'))

    matched_jobs = []

    if os.path.exists('resume_data.csv'):
        with open('resume_data.csv', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            next(reader, None)
            rows = list(reader)
            if rows:
                latest_resume_text = rows[-1][3] if len(rows[-1]) >= 4 else ''
                job_matches = match_jobs_with_resume(latest_resume_text)

                # Add applied status for each match
                for match in job_matches:
                    job = Job.query.filter(Job.title.ilike(f"%{match['title']}%")).first()

                    applied = False
                    if job:
                        applied = Application.query.filter_by(user_id=session['user_id'], job_id=job.id).first() is not None
                    matched_jobs.append({
                        'title': match['title'],
                        'description': match['description'],
                        'match_score': match['score'],
                        'job_id': job.id if job else None,
                        'applied': applied
                    })

    return render_template('jobseeker_dashboard.html', matched_jobs=matched_jobs)


@app.route('/apply/<int:job_id>', methods=['POST'])
@login_required
def apply_to_job(job_id):
    if session.get('role') != 'jobseeker':
        flash('Only job seekers can apply.', 'warning')
        return redirect(url_for('home'))

    existing_application = Application.query.filter_by(
        user_id=session['user_id'], job_id=job_id
    ).first()
    if existing_application:
        flash('You have already applied to this job.', 'info')
    else:
        resume_filename = session.get('resume_filename', None)

        # --- fallback to latest file in uploads if session missing resume filename ---
        if not resume_filename:
            upload_folder = app.config.get("UPLOAD_FOLDER", "uploads")
            try:
                files = [f for f in os.listdir(upload_folder) if os.path.isfile(os.path.join(upload_folder, f))]
                if files:
                    files.sort(key=lambda fn: os.path.getmtime(os.path.join(upload_folder, fn)), reverse=True)
                    resume_filename = files[0]
            except Exception:
                resume_filename = None

        application = Application(
            user_id=session['user_id'],
            job_id=job_id,
            resume_filename=resume_filename
        )

        db.session.add(application)
        db.session.commit()
        flash('Successfully applied to the job!', 'success')

    return redirect(url_for('jobseeker_dashboard'))



@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_resume():
    # only jobseekers can upload
    if session.get('role') != 'jobseeker':
        flash('Access restricted: Please log in as a Job Seeker.', 'warning')
        return redirect(url_for('home'))

    if request.method == 'POST':
        file = request.files.get('resume')
        if not file or file.filename == '':
            flash('No file selected.', 'danger')
            return redirect(request.url)

        if not allowed_file(file.filename):
            flash('Invalid file format.', 'danger')
            return redirect(request.url)

        # secure filename and ensure upload folder exists
        filename = secure_filename(file.filename)
        upload_folder = app.config.get('UPLOAD_FOLDER', 'uploads')
        os.makedirs(upload_folder, exist_ok=True)

        # avoid overwriting existing file by adding a suffix if needed
        save_path = os.path.join(upload_folder, filename)
        if os.path.exists(save_path):
            name, ext = os.path.splitext(filename)
            timestamp = int(time.time())
            filename = f"{name}_{timestamp}{ext}"
            save_path = os.path.join(upload_folder, filename)

        try:
            file.save(save_path)
        except Exception as e:
            flash(f'Failed to save file: {e}', 'danger')
            return redirect(request.url)

        # extract text (handle exceptions per format)
        ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
        try:
            if ext == 'pdf':
                text = extract_text_from_pdf(save_path)
            else:
                text = extract_text_from_docx(save_path)
        except Exception as e:
            text = ""
            flash(f'Uploaded but text extraction failed: {e}', 'warning')

        # analyze / predict / match only if we have text (otherwise use sensible defaults)
        try:
            score = analyze_resume_text(text, filename) if text else 0
        except Exception as e:
            score = 0
            flash(f'Analysis failed: {e}', 'warning')

        try:
            prediction, confidence = predict_resume_strength(text) if text else ("Unknown", 0.0)
        except Exception:
            prediction, confidence = ("Unknown", 0.0)

        try:
            matches = match_jobs_with_resume(text) if text else []
        except Exception:
            matches = []

        # persist relevant info in session so apply_to_job can pick resume_filename
        session['resume_text'] = text
        session['resume_score'] = int(score)
        session['prediction'] = prediction if isinstance(prediction, (int, float)) else prediction
        session['confidence'] = float(confidence) if isinstance(confidence, (int, float)) else 0.0
        session['matches'] = matches
        session['resume_filename'] = filename

        flash(f'Resume uploaded and analyzed. Score: {session["resume_score"]}/6', 'success')
        return redirect(url_for('analyze_resume', filename=filename))

    return render_template('upload.html')

@app.route('/analyze/<filename>')
@login_required
def analyze_resume(filename):
    return render_template('analyze.html',
                           filename=filename,
                           score=session.get('resume_score'),
                           prediction=session.get('prediction'),
                           confidence=session.get('confidence'),
                           matches=session.get('matches'))

# --- Recruiter ---
@app.route('/recruiter/register', methods=['GET', 'POST'])
def recruiter_register():
    if request.method == 'POST':
        username, email, password = request.form['username'], request.form['email'], request.form['password']
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash('Username or Email exists!', 'danger')
            return redirect(url_for('recruiter_register'))

        hashed = generate_password_hash(password)
        db.session.add(User(username=username, email=email, password=hashed, role='recruiter'))
        db.session.commit()
        flash('Recruiter registered!', 'success')
        return redirect(url_for('recruiter_login'))

    return render_template('recruiter_register.html')

@app.route('/recruiter/login', methods=['GET', 'POST'])
def recruiter_login():
    if request.method == 'POST':
        username, password = request.form['username'], request.form['password']
        user = User.query.filter_by(username=username, role='recruiter').first()

        if user and check_password_hash(user.password, password):
            session['user_id'], session['username'], session['role'] = user.id, user.username, 'recruiter'
            flash('Logged in as recruiter!', 'success')
            return redirect(url_for('recruiter_dashboard'))

        flash('Invalid recruiter login.', 'danger')
        return redirect(url_for('recruiter_login'))

    return render_template('recruiter_login.html')

@app.route('/recruiter/dashboard')
@login_required
def recruiter_dashboard():
    if session.get('role') != 'recruiter':
        flash('Access Denied.', 'danger')
        return redirect(url_for('home'))

    # Handle Google login recruiter
    recruiter_id = session.get('user_id')

    if not recruiter_id and session.get('email'):
        email = session['email']
        recruiter = Recruiter.query.filter_by(email=email).first()
        if recruiter:
            recruiter_id = recruiter.id
            session['user_id'] = recruiter_id  # Save to session

    if not recruiter_id:
        flash('Recruiter account not found.', 'danger')
        return redirect(url_for('home'))

    jobs = Job.query.filter_by(recruiter_id=recruiter_id).all()
    return render_template('recruiter_dashboard.html', jobs=jobs)


@app.route('/recruiter/post-job', methods=['GET', 'POST'])
@login_required
def post_job():
    if session.get('role') != 'recruiter':
        flash('Access restricted: This section is only for Recruiters.', 'warning')
        return redirect(url_for('home'))

    if request.method == 'POST':
        title = request.form['title'].strip()
        description = request.form['description'].strip()

        # ✅ Check for duplicate job by same recruiter
        existing_job = Job.query.filter_by(
            recruiter_id=session['user_id'],
            title=title,
            description=description
        ).first()

        if existing_job:
            flash('Duplicate job already exists. Please modify the job details.', 'danger')
            return redirect(url_for('post_job'))

        # ✅ Save to database
        job = Job(title=title, description=description, recruiter_id=session['user_id'])
        db.session.add(job)
        db.session.commit()

        # ✅ Save to jobs.json
        job_entry = {'title': title, 'description': description}
        try:
            jobs = []
            if os.path.exists('jobs.json'):
                with open('jobs.json', 'r') as f:
                    jobs = json.load(f)

            jobs.append(job_entry)
            with open('jobs.json', 'w') as f:
                json.dump(jobs, f, indent=4)
        except Exception as e:
            print("Error writing to jobs.json:", e)

        flash('Job posted successfully!', 'success')
        return redirect(url_for('recruiter_dashboard'))

    return render_template('post_job.html')


@app.route('/recruiter/edit-job/<int:job_id>', methods=['GET', 'POST'])
@login_required
def edit_job(job_id):
    job = Job.query.get_or_404(job_id)
    if job.recruiter_id != session['user_id']:
        flash('Unauthorized', 'danger')
        return redirect(url_for('recruiter_dashboard'))

    if request.method == 'POST':
        job.title = request.form['title']
        job.description = request.form['description']
        db.session.commit()
        flash('Job updated!', 'success')
        return redirect(url_for('recruiter_dashboard'))

    return render_template('edit_job.html', job=job)

@app.route('/recruiter/delete-job/<int:job_id>', methods=['POST'])
@login_required
def delete_job(job_id):
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    job = Job.query.get_or_404(job_id)
    if job.recruiter_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('recruiter_dashboard'))

    # Delete from DB
    db.session.delete(job)
    db.session.commit()

    # Also remove from jobs.json
    try:
        with open('jobs.json', 'r') as f:
            jobs = json.load(f)
        jobs = [j for j in jobs if not (j['title'] == job.title and j['description'] == job.description)]
        with open('jobs.json', 'w') as f:
            json.dump(jobs, f, indent=4)
    except Exception as e:
        print('Error updating jobs.json:', e)

    flash('Job deleted!', 'success')
    return redirect(url_for('recruiter_dashboard'))

@app.route('/recruiter/resumes')
@login_required
def recruiter_resumes():
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    resumes = []
    min_score = request.args.get('min_score', type=int)
    csv_file = 'resume_data.csv'

    if os.path.exists(csv_file):
        with open(csv_file, newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader, None)  # may be None if file empty
            for row in reader:
                # skip rows that are clearly malformed
                if len(row) < 1:
                    continue

                # normalize/pad to 6 columns: filename, excerpt, score, full_text, shortlisted, user_id
                row = row + [''] * (6 - len(row))

                # try to parse score safely
                try:
                    score = int(row[2]) if row[2] != '' else 0
                except Exception:
                    score = 0

                # apply min_score filter
                if min_score is None or score >= (min_score or 0):
                    resumes.append({
                        'filename': row[0],
                        'excerpt': row[1],
                        'score': score,
                        'shortlisted': row[4].strip() if row[4] else 'no',
                        'user_id': row[5].strip() if row[5] else ''
                    })

    return render_template('recruiter_resumes.html', resumes=resumes)

@app.route('/recruiter/resume/<filename>')
@login_required
def view_resume_detail(filename):
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    resume_detail = None
    if os.path.exists('resume_data.csv'):
        with open('resume_data.csv', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader, None)
            for row in reader:
                if len(row) >= 5 and row[0] == filename:
                    resume_detail = {
                        'filename': row[0],
                        'excerpt': row[1],
                        'score': row[2],
                        'full_text': row[3],
                        'shortlisted': row[4]
                    }
                    break
                
    # view_resume_detail() — Line: ~409
    if not resume_detail:
        flash('Unable to display: Resume not found.', 'warning')  # Line: 
        return redirect(url_for('recruiter_resumes'))


    return render_template('resume_detail.html', resume=resume_detail)
@app.route('/recruiter/toggle-shortlist/<filename>', methods=['POST'])
@login_required
def toggle_shortlist(filename):
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    csv_file = 'resume_data.csv'
    updated_rows = []
    found = False
    owner_user_id = None
    headers = None

    if os.path.exists(csv_file):
        with open(csv_file, 'r', encoding='utf-8', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader, None)
            for row in reader:
                # keep malformed rows safe
                if len(row) < 1:
                    updated_rows.append(row)
                    continue

                # normalize to at least 6 columns: filename, excerpt, score, full_text, shortlisted, user_id
                row = row + [''] * (6 - len(row))

                if row[0] == filename:
                    # toggle shortlisted field
                    row[4] = 'no' if row[4].strip().lower() == 'yes' else 'yes'
                    found = True
                    owner_user_id = row[5].strip() if row[5].strip() else None

                updated_rows.append(row)

        if found:
            # write back file with header ensuring user_id is present
            with open(csv_file, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                if headers:
                    hdr = headers
                    # ensure header contains user_id
                    if 'user_id' not in [h.strip().lower() for h in hdr]:
                        hdr = hdr + ['user_id']
                else:
                    hdr = ['filename', 'excerpt', 'score', 'full_text', 'shortlisted', 'user_id']
                writer.writerow(hdr)
                writer.writerows(updated_rows)

            # create DB notification if owner_user_id exists and is an integer
            try:
                if owner_user_id:
                    try:
                        uid = int(owner_user_id)
                    except:
                        uid = None
                    if uid:
                        notif = Notification(
                            user_id=uid,
                            message=f"Your resume ({filename}) was shortlisted by a recruiter.",
                            read=False
                        )
                        db.session.add(notif)
                        db.session.commit()
            except Exception as e:
                # don't break UX on DB errors; log to console
                print("Failed to create notification:", e)

            flash('Shortlist status updated.', 'success')
        else:
            flash('Resume not found.', 'warning')
    else:
        flash('No resumes present.', 'warning')

    return redirect(url_for('recruiter_resumes'))

@app.route('/recruiter/shortlisted-resumes')
@login_required
def recruiter_shortlisted_resumes():
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    resumes = []
    if os.path.exists('resume_data.csv'):
        with open('resume_data.csv', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader, None)
            for row in reader:
                if len(row) >= 5 and row[4].strip().lower() == 'yes':
                    resumes.append({
                        'filename': row[0],
                        'excerpt': row[1],
                        'score': row[2],
                        'shortlisted': row[4]
                    })

    return render_template('recruiter_resumes.html', resumes=resumes)

@app.route('/recruiter/view-applications')
@login_required
def view_applications():
    if session.get('role') != 'recruiter':
        flash('Access denied. Recruiters only.', 'warning')
        return redirect(url_for('home'))

    recruiter_id = session['user_id']
    jobs = Job.query.filter_by(recruiter_id=recruiter_id).all()
    job_ids = [job.id for job in jobs]

    applications = Application.query.filter(Application.job_id.in_(job_ids)).all()

    return render_template('view_applications.html', applications=applications)
@app.route("/google_login")
def google_login():
    """
    Correct Google login flow:
    - Uses session['pending_role'] (set by starter routes) or request.args as fallback.
    - Redirects to Google OAuth if not authorized (preserving pending_role in session).
    - After Google returns, pops pending_role and uses it to create/update the user role.
    - Ensures unique usernames for new accounts.
    - Logs user in via Flask-Login and sets session fields.
    """
    # 1) Determine the intended role (may be stored in session by start routes)
    requested_role = session.get("pending_role") or request.args.get("role")
    # don't pop here yet, keep it until after OAuth completes

    # 2) Start OAuth if not authorized (preserve pending_role in session)
    #    Use next=url_for('google_login') so Google will return here.
    if not google.authorized:
        return redirect(url_for("google.login", next=url_for("google_login")))

    # 3) Fetch user info from Google
    resp = google.get("/oauth2/v2/userinfo")
    if not resp or not resp.ok:
        flash("Failed to fetch user info from Google.", "danger")
        return redirect(url_for("home"))

    info = resp.json()
    email = info.get("email")
    google_name = info.get("name") or (email.split("@")[0] if email else "google_user")

    # 4) After successful OAuth, consume pending_role (if any)
    desired_role = session.pop("pending_role", None) or requested_role
    # normalize desired_role
    if desired_role not in ("recruiter", "jobseeker"):
        desired_role = None

    # 5) Find existing user by email
    user = User.query.filter_by(email=email).first()

    if not user:
        # --- create new user, respect requested role (fallback to jobseeker) ---
        actual_role = desired_role if desired_role in ("recruiter", "jobseeker") else "jobseeker"

        # Ensure unique username (append numbers if needed)
        base_username = (google_name or email.split("@")[0]).strip().replace(" ", "")
        unique_username = base_username or f"user{int(time.time())}"
        counter = 1
        while User.query.filter_by(username=unique_username).first():
            unique_username = f"{base_username}{counter}"
            counter += 1

        user = User(
            username=unique_username,
            email=email,
            password=generate_password_hash(os.urandom(16).hex()),
            role=actual_role
        )
        db.session.add(user)
        db.session.commit()
    else:
        # --- existing user: update role if a desired_role was explicitly chosen ---
        if desired_role in ("recruiter", "jobseeker") and user.role != desired_role:
            user.role = desired_role
            db.session.commit()

    # 6) Log in and set session values (always overwrite session role)
    login_user(user)
    session["user_id"] = user.id
    session["username"] = user.username
    session["email"] = user.email
    session["role"] = user.role

    flash(f"Welcome, {user.username}! You are logged in as {user.role}.", "success")

    # 7) Redirect to the appropriate dashboard
    if user.role == "recruiter":
        return redirect(url_for("recruiter_dashboard"))
    return redirect(url_for("jobseeker_dashboard"))

@app.route('/debug_resume/<path:filename>')
def debug_resume(filename):
    # read CSV and find the row for filename, then return repr of full_text
    import csv, html
    row_text = None
    if not os.path.exists('resume_data.csv'):
        return "resume_data.csv not found", 404

    with open('resume_data.csv', newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        headers = next(reader, None)
        for row in reader:
            if len(row) >= 4 and row[0] == filename:
                row_text = row[3]
                break

    if row_text is None:
        return f"Resume '{filename}' not found in CSV", 404

    # return safe HTML showing repr and whether there's an actual newline
    repr_text = repr(row_text)
    has_newline = ("\n" in row_text)
    # escape repr_text for safe display
    return (
        "<pre style='white-space:pre-wrap;'>"
        f"FILENAME: {html.escape(filename)}\n\n"
        f"HAS_NEWLINE: {has_newline}\n\n"
        f"REPR:\n{html.escape(repr_text)}"
        "</pre>"
    )



@app.route("/login/google/recruiter")
def start_google_recruiter():
    session['pending_role'] = 'recruiter'
    session.pop('google_oauth_token', None)
    return redirect(url_for('google.login', next=url_for('google_login')))

@app.route("/login/google/jobseeker")
def start_google_jobseeker():
    session['pending_role'] = 'jobseeker'
    session.pop('google_oauth_token', None)
    return redirect(url_for('google.login', next=url_for('google_login')))

@app.context_processor
def inject_unread_notifications():
    unread = 0
    try:
        if 'user_id' in session:
            unread = Notification.query.filter_by(user_id=session['user_id'], read=False).count()
    except Exception:
        unread = 0
    return dict(unread_notifications=unread)



@app.route('/notifications/mark-read/<int:notif_id>', methods=['POST'])
@login_required
def mark_notification_read(notif_id):
    notif = Notification.query.get_or_404(notif_id)
    if notif.user_id != session['user_id']:
        flash('Unauthorized', 'danger')
        return redirect(url_for('jobseeker_notifications'))

    notif.read = True
    db.session.commit()
    return redirect(request.referrer or url_for('jobseeker_notifications'))

@app.route('/jobseeker/notifications')
@login_required
def jobseeker_notifications():
    if session.get('role') != 'jobseeker':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    user_id = session.get('user_id')

    notifications = Notification.query.filter_by(
        user_id=user_id
    ).order_by(Notification.timestamp.desc()).all()

    unread_notifications = Notification.query.filter_by(
        user_id=user_id, read=False
    ).count()

    return render_template(
        'jobseeker_notifications.html',
        notifications=notifications,
        unread_notifications=unread_notifications
    )


# --------- RUN ---------
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

# get_user_id.py
import sqlite3
db = 'jobgenie.db'
email = 'khanmufeez95@gmail.com'
conn = sqlite3.connect(db)
cur = conn.cursor()
cur.execute("SELECT id, username, email FROM user WHERE email = ?", (email,))
row = cur.fetchone()
if row:
    print("FOUND:", row)   # prints e.g. (3, 'mufeez', 'khanmufeez95@gmail.com')
else:
    print("No user with that email found.")
conn.close()

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib

# Load dataset
df = pd.read_csv('resume_dataset.csv')

# Vectorize text
vectorizer = TfidfVectorizer(stop_words='english', max_features=300)
X = vectorizer.fit_transform(df['resume_text'])
y = df['label']

# Train model
model = LogisticRegression()
model.fit(X, y)

# Save model and vectorizer
joblib.dump(model, 'model/resume_model.pkl')
joblib.dump(vectorizer, 'model/tfidf.pkl')

print("✅ Model and vectorizer saved.")

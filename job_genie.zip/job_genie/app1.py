from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_dance.contrib.google import make_google_blueprint, google
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
import os, csv, fitz, docx, spacy, json, joblib

# ✅ Allow OAuth over HTTP (only for development/testing)
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

# ✅ Define the Flask app FIRST
app = Flask(__name__)
app.secret_key = '11223344'

# --- Google OAuth (Flask-Dance) ---



google_bp = make_google_blueprint(
    client_id="942342789678-pknk9i6ug52rikttiqe4na78jl1inq9i.apps.googleusercontent.com",
    client_secret="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",
    scope=[
        "https://www.googleapis.com/auth/userinfo.profile",
        "https://www.googleapis.com/auth/userinfo.email",
        "openid"
    ],
    redirect_to="google_login",
    reprompt_consent=True   # ✅ force Google to ask account each login
)
app.register_blueprint(google_bp, url_prefix="/login")



# Upload Config
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'docx'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Database Config
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///jobgenie.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except Exception:
        return None

# NLP and ML
nlp = spacy.load("en_core_web_sm")
model = joblib.load('model/resume_model.pkl')
vectorizer = joblib.load('model/tfidf.pkl')

# --------- MODELS ---------
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False, unique=True)
    email = db.Column(db.String(120), nullable=False, unique=True)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='jobseeker')
    applications = db.relationship('Application', backref='user', lazy=True)

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    recruiter_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    applications = db.relationship('Application', backref='job', lazy=True)

    __table_args__ = (db.UniqueConstraint('recruiter_id', 'title', 'description', name='unique_job_post'),)

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    resume_filename = db.Column(db.String(200))  # 👈 Add this line

    __table_args__ = (db.UniqueConstraint('user_id', 'job_id', name='unique_application'),)

# --------- HELPERS ---------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# (removed custom login_required wrapper so we use flask_login.login_required)

def extract_text_from_pdf(path):
    text = ""
    with fitz.open(path) as doc:
        for page in doc:
            text += page.get_text()
    return text

def extract_text_from_docx(path):
    doc = docx.Document(path)
    return "\n".join(para.text for para in doc.paragraphs)

def analyze_resume_text(text, filename):
    doc = nlp(text)
    tokens = [t.text.lower() for t in doc if not t.is_stop and not t.is_punct]
    keywords = ['python', 'flask', 'machine learning', 'nlp', 'sql', 'django']
    score = sum(1 for word in keywords if word in tokens)

    # Save with proper quoting
    file_exists = os.path.exists('resume_data.csv')
    with open('resume_data.csv', 'a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file, quoting=csv.QUOTE_ALL)
        if not file_exists:
            writer.writerow(['filename', 'excerpt', 'score', 'full_text', 'shortlisted'])
        writer.writerow([
            filename,
            text[:100].replace('\n', ' ') + "...",
            score,
            text,
            'no'
        ])
    return int(score)

def predict_resume_strength(text):
    vec = vectorizer.transform([text])
    label = int(model.predict(vec)[0])
    conf = float(model.predict_proba(vec)[0][label])
    return label, round(conf * 100)

def match_jobs_with_resume(resume_text):
    try:
        with open('jobs.json') as f:
            job_data = json.load(f)
    except FileNotFoundError:
        return []

    resume_tokens = {t.text for t in nlp(resume_text.lower()) if not t.is_stop and not t.is_punct}
    matches = []

    for job in job_data:
        job_tokens = {t.text for t in nlp(job['description'].lower()) if not t.is_stop and not t.is_punct}
        common = resume_tokens.intersection(job_tokens)
        score = int((len(common) / len(job_tokens)) * 100) if job_tokens else 0

        # 🧠 Look up Job ID from the database using title and description
        job_db = Job.query.filter_by(title=job['title'], description=job['description']).first()
        job_id = job_db.id if job_db else None

        matches.append({
            'title': job['title'],
            'description': job['description'],
            'score': score,
            'skills_matched': list(common),
            'job_id': job_id
        })

    matches.sort(key=lambda x: x['score'], reverse=True)
    return matches[:3]

# --------- ROUTES ---------

@app.route('/')
def home():
    return render_template('index.html')

# --- Authentication ---
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username, email, password = request.form['username'], request.form['email'], request.form['password']
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash('Username or Email exists!', 'danger')
            return redirect(url_for('register'))

        hashed = generate_password_hash(password)
        user = User(username=username, email=email, password=hashed, role='jobseeker')
        db.session.add(user)
        db.session.commit()
        flash('Registered! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username, password = request.form['username'], request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            login_user(user)  # Flask-Login
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            flash('Logged in!', 'success')
            return redirect(url_for('recruiter_dashboard') if user.role == 'recruiter' else url_for('jobseeker_dashboard'))

        flash('Invalid credentials.', 'danger')
        return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.clear()

    # ✅ Explicitly clear Google OAuth token
    if "google_oauth_token" in session:
        session.pop("google_oauth_token")

    flash("Logged out successfully.", "info")
    return redirect(url_for("home"))

# --- Job Seeker ---
@app.route('/jobseeker/dashboard')
@login_required
def jobseeker_dashboard():
    # role guard
    if session.get('role') != 'jobseeker':
        flash('Access Denied.', 'danger')
        return redirect(url_for('home'))

    matched_jobs = []

    if os.path.exists('resume_data.csv'):
        with open('resume_data.csv', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            next(reader, None)
            rows = list(reader)
            if rows:
                latest_resume_text = rows[-1][3] if len(rows[-1]) >= 4 else ''
                job_matches = match_jobs_with_resume(latest_resume_text)

                # Add applied status for each match
                for match in job_matches:
                    job = Job.query.filter(Job.title.ilike(f"%{match['title']}%")).first()

                    applied = False
                    if job:
                        applied = Application.query.filter_by(user_id=session['user_id'], job_id=job.id).first() is not None
                    matched_jobs.append({
                        'title': match['title'],
                        'description': match['description'],
                        'match_score': match['score'],
                        'job_id': job.id if job else None,
                        'applied': applied
                    })

    return render_template('jobseeker_dashboard.html', matched_jobs=matched_jobs)

@app.route('/apply/<int:job_id>', methods=['POST'])
@login_required
def apply_to_job(job_id):
    if session.get('role') != 'jobseeker':
        flash('Only job seekers can apply.', 'warning')
        return redirect(url_for('home'))

    existing_application = Application.query.filter_by(user_id=session['user_id'], job_id=job_id).first()
    if existing_application:
        flash('You have already applied to this job.', 'info')
    else:
        resume_filename = session.get('resume_filename', None)
        application = Application(user_id=session['user_id'], job_id=job_id, resume_filename=resume_filename)

        db.session.add(application)
        db.session.commit()
        flash('Successfully applied to the job!', 'success')

    return redirect(url_for('jobseeker_dashboard'))

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_resume():
    if session.get('role') != 'jobseeker':
        flash('Access restricted: Please log in as a Job Seeker.', 'warning')
        return redirect(url_for('home'))

    if request.method == 'POST':
        file = request.files.get('resume')
        if not file or file.filename == '':
            flash('No file selected.', 'danger')
            return redirect(request.url)

        if allowed_file(file.filename):
            filename = secure_filename(file.filename)
            path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(path)
            ext = filename.rsplit('.', 1)[1].lower()

            text = extract_text_from_pdf(path) if ext == 'pdf' else extract_text_from_docx(path)
            score = analyze_resume_text(text, filename)
            prediction, confidence = predict_resume_strength(text)
            matches = match_jobs_with_resume(text)

            session['resume_text'] = text
            session['resume_score'] = int(score)
            session['prediction'] = int(prediction)
            session['confidence'] = float(confidence)
            session['matches'] = matches
            session['resume_filename'] = filename

            flash(f'Resume Score: {score}/6', 'success')
            return redirect(url_for('analyze_resume', filename=filename))

        flash('Invalid file format.', 'danger')

    return render_template('upload.html')

@app.route('/analyze/<filename>')
@login_required
def analyze_resume(filename):
    return render_template('analyze.html',
                           filename=filename,
                           score=session.get('resume_score'),
                           prediction=session.get('prediction'),
                           confidence=session.get('confidence'),
                           matches=session.get('matches'))

# --- Recruiter ---
@app.route('/recruiter/register', methods=['GET', 'POST'])
def recruiter_register():
    if request.method == 'POST':
        username, email, password = request.form['username'], request.form['email'], request.form['password']
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash('Username or Email exists!', 'danger')
            return redirect(url_for('recruiter_register'))

        hashed = generate_password_hash(password)
        user = User(username=username, email=email, password=hashed, role='recruiter')
        db.session.add(user)
        db.session.commit()
        flash('Recruiter registered!', 'success')
        return redirect(url_for('recruiter_login'))

    return render_template('recruiter_register.html')

@app.route('/recruiter/login', methods=['GET', 'POST'])
def recruiter_login():
    if request.method == 'POST':
        username, password = request.form['username'], request.form['password']
        user = User.query.filter_by(username=username, role='recruiter').first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            session['user_id'], session['username'], session['role'] = user.id, user.username, 'recruiter'
            flash('Logged in as recruiter!', 'success')
            return redirect(url_for('recruiter_dashboard'))

        flash('Invalid recruiter login.', 'danger')
        return redirect(url_for('recruiter_login'))

    return render_template('recruiter_login.html')

@app.route('/recruiter/dashboard')
@login_required
def recruiter_dashboard():
    if session.get('role') != 'recruiter':
        flash('Access Denied.', 'danger')
        return redirect(url_for('home'))

    # Handle Google login recruiter (if any email in session)
    recruiter_id = session.get('user_id')

    if not recruiter_id and session.get('email'):
        email = session['email']
        recruiter = User.query.filter_by(email=email).first()
        if recruiter:
            recruiter_id = recruiter.id
            session['user_id'] = recruiter_id  # Save to session

    if not recruiter_id:
        flash('Recruiter account not found.', 'danger')
        return redirect(url_for('home'))

    jobs = Job.query.filter_by(recruiter_id=recruiter_id).all()
    return render_template('recruiter_dashboard.html', jobs=jobs)

@app.route('/recruiter/post-job', methods=['GET', 'POST'])
@login_required
def post_job():
    if session.get('role') != 'recruiter':
        flash('Access restricted: This section is only for Recruiters.', 'warning')
        return redirect(url_for('home'))

    if request.method == 'POST':
        title = request.form['title'].strip()
        description = request.form['description'].strip()

        # ✅ Check for duplicate job by same recruiter
        existing_job = Job.query.filter_by(
            recruiter_id=session['user_id'],
            title=title,
            description=description
        ).first()

        if existing_job:
            flash('Duplicate job already exists. Please modify the job details.', 'danger')
            return redirect(url_for('post_job'))

        # ✅ Save to database
        job = Job(title=title, description=description, recruiter_id=session['user_id'])
        db.session.add(job)
        db.session.commit()

        # ✅ Save to jobs.json
        job_entry = {'title': title, 'description': description}
        try:
            jobs = []
            if os.path.exists('jobs.json'):
                with open('jobs.json', 'r') as f:
                    jobs = json.load(f)

            jobs.append(job_entry)
            with open('jobs.json', 'w') as f:
                json.dump(jobs, f, indent=4)
        except Exception as e:
            print("Error writing to jobs.json:", e)

        flash('Job posted successfully!', 'success')
        return redirect(url_for('recruiter_dashboard'))

    return render_template('post_job.html')

@app.route('/recruiter/edit-job/<int:job_id>', methods=['GET', 'POST'])
@login_required
def edit_job(job_id):
    job = Job.query.get_or_404(job_id)
    if job.recruiter_id != session['user_id']:
        flash('Unauthorized', 'danger')
        return redirect(url_for('recruiter_dashboard'))

    if request.method == 'POST':
        job.title = request.form['title']
        job.description = request.form['description']
        db.session.commit()
        flash('Job updated!', 'success')
        return redirect(url_for('recruiter_dashboard'))

    return render_template('edit_job.html', job=job)

@app.route('/recruiter/delete-job/<int:job_id>', methods=['POST'])
@login_required
def delete_job(job_id):
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    job = Job.query.get_or_404(job_id)
    if job.recruiter_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('recruiter_dashboard'))

    # Delete from DB
    db.session.delete(job)
    db.session.commit()

    # Also remove from jobs.json
    try:
        with open('jobs.json', 'r') as f:
            jobs = json.load(f)
        jobs = [j for j in jobs if not (j['title'] == job.title and j['description'] == job.description)]
        with open('jobs.json', 'w') as f:
            json.dump(jobs, f, indent=4)
    except Exception as e:
        print('Error updating jobs.json:', e)

    flash('Job deleted!', 'success')
    return redirect(url_for('recruiter_dashboard'))

@app.route('/recruiter/resumes')
@login_required
def recruiter_resumes():
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    resumes = []
    min_score = request.args.get('min_score', type=int)

    if os.path.exists('resume_data.csv'):
        with open('resume_data.csv', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader, None)  # Skip header
            for row in reader:
                if len(row) >= 5:
                    try:
                        score = int(row[2])
                        if min_score is None or score >= min_score:
                            resumes.append({
                                'filename': row[0],
                                'excerpt': row[1],
                                'score': score,
                                'shortlisted': row[4]
                            })
                    except ValueError:
                        continue  # Skip invalid rows

    return render_template('recruiter_resumes.html', resumes=resumes)

@app.route('/recruiter/resume/<filename>')
@login_required
def view_resume_detail(filename):
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    resume_detail = None
    if os.path.exists('resume_data.csv'):
        with open('resume_data.csv', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader, None)
            for row in reader:
                if len(row) >= 5 and row[0] == filename:
                    resume_detail = {
                        'filename': row[0],
                        'excerpt': row[1],
                        'score': row[2],
                        'full_text': row[3],
                        'shortlisted': row[4]
                    }
                    break

    if not resume_detail:
        flash('Unable to display: Resume not found.', 'warning')
        return redirect(url_for('recruiter_resumes'))

    return render_template('resume_detail.html', resume=resume_detail)

@app.route('/recruiter/toggle-shortlist/<filename>', methods=['POST'])
@login_required
def toggle_shortlist(filename):
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    updated_rows = []
    found = False

    if os.path.exists('resume_data.csv'):
        with open('resume_data.csv', 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader, None)
            for row in reader:
                if len(row) >= 4:
                    while len(row) < 5:
                        row.append('no')
                    if row[0] == filename:
                        row[4] = 'no' if row[4] == 'yes' else 'yes'
                        found = True
                updated_rows.append(row)

        if found:
            with open('resume_data.csv', 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(headers or ['filename', 'excerpt', 'score', 'full_text', 'shortlisted'])
                writer.writerows(updated_rows)
            flash('Shortlist status updated.', 'success')
        else:
            flash('Resume not found.', 'warning')

    return redirect(url_for('recruiter_resumes'))

@app.route('/recruiter/shortlisted-resumes')
@login_required
def recruiter_shortlisted_resumes():
    if session.get('role') != 'recruiter':
        flash('Access denied.', 'danger')
        return redirect(url_for('home'))

    resumes = []
    if os.path.exists('resume_data.csv'):
        with open('resume_data.csv', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader, None)
            for row in reader:
                if len(row) >= 5 and row[4].strip().lower() == 'yes':
                    resumes.append({
                        'filename': row[0],
                        'excerpt': row[1],
                        'score': row[2],
                        'shortlisted': row[4]
                    })

    return render_template('recruiter_resumes.html', resumes=resumes)

@app.route('/recruiter/view-applications')
@login_required
def view_applications():
    if session.get('role') != 'recruiter':
        flash('Access denied. Recruiters only.', 'warning')
        return redirect(url_for('home'))

    recruiter_id = session['user_id']
    jobs = Job.query.filter_by(recruiter_id=recruiter_id).all()
    job_ids = [job.id for job in jobs]

    applications = Application.query.filter(Application.job_id.in_(job_ids)).all()

    return render_template('view_applications.html', applications=applications)
@app.route("/google_login")
def google_login():
    # --- Get the role from the button ---
    desired_role = request.args.get("role")  # recruiter or jobseeker
    print("🚀 Google Login Role Param:", desired_role)   # DEBUG in console

    # --- If no token yet, redirect to Google with role preserved ---
    if "google_oauth_token" not in session:
        return redirect(url_for(
            "google.login",
            next=url_for("google_login", role=desired_role)  # ✅ preserve role
        ))

    # --- Fetch user info from Google ---
    resp = google.get("/oauth2/v2/userinfo")
    if not resp or not resp.ok:
        flash("Failed to fetch user info from Google.", "danger")
        return redirect(url_for("home"))

    info = resp.json()
    email = info.get("email")
    google_name = info.get("name") or (email.split("@")[0] if email else "Google_User")

    user = User.query.filter_by(email=email).first()

    if not user:
        # --- Always respect the button role ---
        actual_role = "recruiter" if desired_role == "recruiter" else "jobseeker"

        # --- Ensure unique username ---
        base_username = google_name
        unique_username = base_username
        counter = 1
        while User.query.filter_by(username=unique_username).first():
            unique_username = f"{base_username}{counter}"
            counter += 1

        # --- Create new Google user ---
        user = User(
            username=unique_username,
            email=email,
            password=generate_password_hash(os.urandom(16).hex()),
            role=actual_role
        )
        db.session.add(user)
        db.session.commit()
    else:
        # --- Update role if login button chosen differently ---
        if desired_role in ["recruiter", "jobseeker"] and user.role != desired_role:
            user.role = desired_role
            db.session.commit()

    # --- Login and sync session ---
    login_user(user)
    session["role"] = user.role
    session["user_id"] = user.id
    session["username"] = google_name
    session["email"] = email

    flash(f"Welcome, {google_name}! You are logged in as {user.role}.", "success")

    return redirect(
        url_for("recruiter_dashboard" if user.role == "recruiter" else "jobseeker_dashboard")
    )
# --------- RUN ---------
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

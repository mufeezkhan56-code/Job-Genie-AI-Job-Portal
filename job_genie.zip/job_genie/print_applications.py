# print_applications.py
from app import app, db, Application

with app.app_context():
    apps = Application.query.order_by(Application.id).all()
    if not apps:
        print("No applications found.")
    for a in apps:
        print(f"ID={a.id}  user_id={a.user_id}  job_id={a.job_id}  resume_filename={a.resume_filename!r}")
